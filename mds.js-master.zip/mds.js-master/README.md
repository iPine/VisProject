mds.js
=======

Classic Multidimensional scaling code in javascript

The code is taken from my [blog
post](http://www.benfrederickson.com/2013/05/16/multidimensional-scaling.html)
on this - which also contains examples of how it works.

Released under the MIT License.
